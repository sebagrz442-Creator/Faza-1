# ENV (produkcyjne)
W pliku `.env` ustaw co najmniej:
- OPENAI_API_KEY=...  (wymagane)
- PORT=3000
- BASE_URL=https://twoja.domena

**Admin & Watchtower**
- ADMIN_TOKEN=...  (silny token do panelu Admin)
- WATCHTOWER_HTTP_API_TOKEN=...  (do przycisku Update now)

**TikTok (gdy będziesz gotów)**
- TIKTOK_CLIENT_KEY=
- TIKTOK_CLIENT_SECRET=
- TIKTOK_REDIRECT_URI=https://twoja.domena/api/tiktok/callback
- TIKTOK_SCOPES="video.upload video.publish"

**FFmpeg (opcjonalnie na małych maszynach)**
- FFMPEG_THREADS=2
- FFMPEG_PRESET=fast

**Fonts (opcjonalnie)**
- OVERLAY_FONT_FILE=/app/assets/fonts/YourFont.ttf
- CAPTION_FONT_FILE=/app/assets/fonts/YourFont.ttf
