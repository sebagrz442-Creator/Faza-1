# TikTok – integracja (po uzyskaniu dostępu do Content Posting API)
1) TikTok for Developers -> utwórz app -> produkt: Content Posting API.
2) Włącz zakresy: `video.upload` (draft) + `video.publish` (direct post).
3) Ustaw `TIKTOK_REDIRECT_URI` -> `https://twoja.domena/api/tiktok/callback`.
4) W `.env` wstaw `TIKTOK_CLIENT_KEY`, `TIKTOK_CLIENT_SECRET`, `TIKTOK_REDIRECT_URI`.
5) W dashboardzie: sekcja TikTok -> **Connect** -> autoryzacja konta.
6) Połączone? Klikaj **Upload as Draft** albo **Direct Post** (zaczynaj od prywatnych testów).
