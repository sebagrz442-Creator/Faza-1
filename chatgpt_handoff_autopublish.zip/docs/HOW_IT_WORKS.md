# Jak to działa (skrót)
- **Pipeline**: tematy -> skrypt -> lektor -> sceny -> render (Sora lub fallback FFmpeg) -> napisy/CTA -> zapis do `videos/`.
- **Dashboard PWA**: sterowanie z telefonu, Admin (auto-run, Update now, Check updates).
- **Produkcja**: Docker + Caddy (HTTPS) + Watchtower (auto-update) + GHCR (build z GitHub Actions).
- **Bezpieczeństwo**: ADMIN_TOKEN wymagany dla endpointów admin.
- **Trwałość**: `videos/` i `assets/` montowane jako volume (przetrwają aktualizacje).
