# Uruchomienie na serwerze (Hetzner CX22)
# 1) docker + firewall
apt-get update -y && apt-get install -y ca-certificates curl ufw
curl -fsSL https://get.docker.com | sh
ufw allow 22/tcp && ufw allow 80/tcp && ufw allow 443/tcp && ufw --force enable

# 2) DNS: A twoja.domena -> IP serwera
# 3) Wgraj project.zip do /opt/autopublish i rozpakuj
unzip project.zip -d /opt/autopublish && cd /opt/autopublish
cp .env.example.production .env && nano .env   # ustaw klucze

# 4) Start (prod + limity + profil CX22)
docker compose -f docker-compose.yml -f docker-compose.prod.yml -f docker-compose.cx22.yml up -d --build

# 5) Panel
# https://twoja.domena/dashboard
