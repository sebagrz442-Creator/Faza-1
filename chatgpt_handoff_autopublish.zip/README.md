# ChatGPT Handoff — Autopublish Sora (snapshot)
Snapshot time (UTC): **2025-12-10T17:17:53Z**

Co jest w tym pakiecie:
- **/project.zip** – najnowsza wersja projektu (Hetzner CX22 + PWA + Admin + GHCR + Watchtower + limity).
- **/docs/** – instrukcje: uruchomienie, .env, komendy, TikTok API, produkcja na Hetzner.
- **/narration/** – odtwarzacze lektora (PL/DE) i skrypty SSML (offline).
- **/state.json** – skrót decyzji i ustawień.

Ten pakiet wrzuć w nowym czacie ChatGPT, aby szybko kontynuować pracę.
