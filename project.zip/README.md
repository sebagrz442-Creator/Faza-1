# Autopublish Sora – Full Pipeline

Trends → script → edit → voice plan → **Sora** (or **fallback slideshow with Ken Burns + transitions**) → analysis → **TTS** → ffmpeg merge. 15–40 s.

## Highlights
- **TikTok = 100% English** (enforced).
- **Captions** burned-in (ASS, auto-timed) + **music ducking**.
- **Safe Areas:** `none`, `tiktok`, `tiktok_strict`.
- **Fonts:** overlay/captions font names + sizes; optional TTF via `.env` (`OVERLAY_FONT_FILE`, `CAPTION_FONT_FILE`).
- **Uploads:** drag&drop to `assets/images/<slug>`.
- **Metadata:** alongside `final_xxx.mp4` you get `final_xxx.txt` and `final_xxx.json`.
- **Dashboard:** http://localhost:3000/dashboard

## Quick start (Windows)
1) Unzip so `server.js` and `package.json` are in the same folder.
2) Double-click `start.bat` (installs deps, creates `.env`, asks for `OPENAI_API_KEY`, runs the server).
3) Open http://localhost:3000/dashboard
4) Diagnostics: `./check.ps1`

## API
- `POST /api/pipeline/run` – body: `{ topic, platform, audienceLanguage, durationSec, options }`
- `GET  /api/videos` – list generated videos (+ meta)
- `GET  /api/trends` – ideas by topic/platform/lang
- `POST /api/bot/ideas` – freeform ideas

## Fallback (no Sora)
FFmpeg-only **9:16 slideshow** (1080×1920, 30fps) with **Ken Burns**, **random transitions**, **hooks/CTA overlays**, **progress bar**.
Requires `ffmpeg` and `ffprobe` in PATH.
