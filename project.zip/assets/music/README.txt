Put your background music as 'bg.mp3' here.
