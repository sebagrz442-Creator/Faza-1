import { exec as execCb } from "node:child_process";
import { promisify } from "node:util";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
const exec = promisify(execCb);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");

function escSubPath(p) { return p.replace(/\\/g, "\\\\").replace(/:/g, "\\:"); }

async function probeDurationSec(filePath) {
  const cmd = `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${filePath}"`;
  try { const { stdout } = await exec(cmd); const n = parseFloat(String(stdout).trim()); return Number.isFinite(n) ? n : 0; }
  catch { return 0; }
}
function chunkSentences(text) {
  const cleaned = String(text || "").replace(/\s+/g, " ").trim(); if (!cleaned) return [];
  const parts = cleaned.split(/(?<=[\.!\?])\s+/);
  const res = [];
  for (const p of parts) {
    if (p.length <= 56) { res.push(p); continue; }
    let s = 0; while (s < p.length) { const e = Math.min(p.length, s + 48); res.push(p.slice(s, e)); s = e; }
  }
  return res;
}
function makeAss(cues, style={}) {
  const { Fontname="Arial", Fontsize=48, PrimaryColour="&H00FFFFFF", OutlineColour="&H00101010", BackColour="&H80000000", BorderStyle=3, Outline=2, Shadow=0, Alignment=8, MarginV=80 } = style;
  const header = [
    "[Script Info]","ScriptType: v4.00+","PlayResX: 1080","PlayResY: 1920","",
    "[V4+ Styles]","Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    `Style: Default,${Fontname},${Fontsize},${PrimaryColour},&H000000FF,${OutlineColour},${BackColour},0,0,0,0,100,100,0,0,${BorderStyle},${Outline},${Shadow},${Alignment},10,10,${MarginV},1`,"",
    "[Events]","Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
  ].join("\n");
  const lines = cues.map(c => `Dialogue: 0,${fmtTS(c.start)},${fmtTS(c.end)},Default,,0,0,0,,${c.text.replace(/,/g, "\\,")}`);
  return header + "\n" + lines.join("\n") + "\n";
}
function fmtTS(sec){const s=Math.max(0,sec);const h=Math.floor(s/3600).toString().padStart(1,"0");const m=Math.floor((s%3600)/60).toString().padStart(2,"0");const sc=Math.floor(s%60).toString().padStart(2,"0");const cs=Math.floor((s*100)%100).toString().padStart(2,"0");return `${h}:${m}:${sc}.${cs}`;}

export async function mergeVideoAndAudio({
  videoPath,
  audioPath,
  captionsText,
  burnCaptions = true,
  addMusicIfAvailable = true,
  overlayCtaText,
  overlayProgressBar = true,
  overlaySafeArea = "tiktok",     // "tiktok" | "tiktok_strict" | "none"
  progressThickness = 8,
  overlayFontName = "Arial",
  overlayHookSize = 48,
  overlayCtaSize = 44,
  captionFontName = "Arial",
  captionFontSize = 48
}) {
  const ts = Date.now();
  const outPath = path.join(projectRoot, "videos", `final_${ts}.mp4`);

  // captions → ASS
  let assPath = null;
  if (burnCaptions && captionsText) {
    const dur = await probeDurationSec(audioPath);
    const chunks = chunkSentences(captionsText);
    if (chunks.length) {
      const totalChars = chunks.reduce((s,t)=>s + t.length, 0) || 1;
      let t = 0;
      const cues = chunks.map((txt, idx) => {
        const d = Math.max(0.8, (txt.length / totalChars) * (dur || chunks.length * 1.2));
        const start = t; const end = idx === chunks.length - 1 ? Math.max(dur, start + d) : start + d; t = end;
        return { start, end, text: txt };
      });
      assPath = path.join(projectRoot, "videos", `cap_${ts}.ass`);
      fs.writeFileSync(assPath, makeAss(cues, { Fontname: captionFontName, Fontsize: captionFontSize }), "utf-8");
    }
  }

  const musicPath = path.join(projectRoot, "assets", "music", "bg.mp3");
  const hasMusic = addMusicIfAvailable && fs.existsSync(musicPath);

  const vdur = await probeDurationSec(videoPath);
  const pad = (overlaySafeArea === "tiktok") ? { top: 220, bottom: 420, left: 80, right: 80 }
             : (overlaySafeArea === "tiktok_strict") ? { top: 300, bottom: 560, left: 100, right: 100 }
             : { top: 80, bottom: 120, left: 40, right: 40 };
  const barH = Math.max(2, Math.min(24, Number(progressThickness)||8));

  const vfParts = [];
  if (assPath) vfParts.push(`subtitles='${escSubPath(assPath)}'`);
  if (overlayCtaText) {
    const cta = String(overlayCtaText).replace(/['"]/g, "");
    const fontfile = process.env.OVERLAY_FONT_FILE ? `fontfile='${escSubPath(process.env.OVERLAY_FONT_FILE)}':` : "";
    vfParts.push(`drawtext=${fontfile}text='${cta}':x=(w-text_w)/2:y=(h - ${pad.bottom} - text_h - 10):fontsize=${overlayCtaSize}:fontcolor=white:box=1:boxcolor=black@0.5:boxborderw=10:enable='between(t,${Math.max(0, vdur-3).toFixed(2)},${vdur.toFixed(2)})'`);
  }
  if (overlayProgressBar) {
    vfParts.push(`drawbox=x=0:y=(${pad.top} - (10 + ${barH})):w=(w*t/${Math.max(0.1, vdur).toFixed(2)}):h=${barH}:color=white@0.6:t=fill:enable='between(t,0,${Math.max(0.1, vdur).toFixed(2)})'`);
  }
  const vf = vfParts.length ? `-vf "${vfParts.join(",")}"` : "";

  // audio filter: ducking if music present
  let filterComplex = "";
  let mapAudio = "-map 1:a";
  if (hasMusic) {
    filterComplex = `-filter_complex "[2:a]volume=0.08[bg];[bg][1:a]sidechaincompress=threshold=0.08:ratio=8:attack=50:release=250[aout]"`;
    mapAudio = `-map "[aout]"`;
  }

  const cmd = [
    "ffmpeg -y",
    `-i "${videoPath}"`,
    `-i "${audioPath}"`,
    hasMusic ? `-i "${musicPath}"` : "",
    filterComplex,
    "-map 0:v",
    mapAudio,
    vf,
    "-c:v libx264 -pix_fmt yuv420p -c:a aac -shortest",
    `"${outPath}"`
  ].filter(Boolean).join(" ");

  await exec(cmd);
  if (assPath) { try { fs.unlinkSync(assPath); } catch {} }
  return outPath;
}
