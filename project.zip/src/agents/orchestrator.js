import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { loadConfig } from "../lib/config.js";
import { slugify, readImagesFromTopicFolder } from "../lib/utils.js";
import { generateTrendIdeas } from "./trend_agent.js";
import { generateScript } from "./script_agent.js";
import { editScript } from "./editor_agent.js";
import { planVoiceAndVideo } from "./voice_director_agent.js";
import { generateVideoWithSora } from "../video/sora_agent.js";
import { generateVideoFallback } from "../video/slideshow_fallback.js";
import { analyzeVideo } from "./video_analyzer_agent.js";
import { generateNarration } from "./narrator_agent.js";
import { mergeVideoAndAudio } from "./video_edit_agent.js";
import { generateCtaAndTags } from "./cta_tags_agent.js";
import { generateDescription } from "./description_agent.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");

export async function runFullPipeline({
  topic,
  platform = "TikTok",
  audienceLanguage = "English",
  durationSec,
  options = {}
}) {
  const cfg = loadConfig();
  const slug = slugify(topic || "auto-topic");

  // TikTok => always English
  const usedLanguage = String(platform || "").toLowerCase() === "tiktok"
    ? "English"
    : audienceLanguage;

  const ideas = await generateTrendIdeas({ topic, platform, audienceLanguage: usedLanguage });
  const idea = ideas[0] || (topic || "Untitled");

  const script = await generateScript({ idea, platform, audienceLanguage: usedLanguage });
  const edited = await editScript({ script, audienceLanguage: usedLanguage });
  const plan = await planVoiceAndVideo({ editedScript: edited, audienceLanguage: usedLanguage });

  const { cta, hashtags } = await generateCtaAndTags({ platform, topic: idea, language: usedLanguage });

  const images = readImagesFromTopicFolder(projectRoot, cfg.IMAGES_DIR, slug, cfg.MAX_IMAGES);

  const sceneOpts = {
    zoomMode: options.zoomMode || "mix",
    transitionsMode: options.transitionsMode || "auto",
    progressBar: options.progressBar !== false,
    safeArea: options.safeArea || (String(platform||"").toLowerCase()==="tiktok" ? "tiktok" : "none"),
    progressThickness: Number.isFinite(options.progressThickness) ? Math.max(2, Math.min(24, Number(options.progressThickness))) : 8,
    overlayFontName: options.overlayFontName || "Arial",
    overlayHookSize: Number.isFinite(options.overlayHookSize) ? Math.max(18, Math.min(96, Number(options.overlayHookSize))) : 48,
    overlayCtaSize: Number.isFinite(options.overlayCtaSize) ? Math.max(18, Math.min(96, Number(options.overlayCtaSize))) : 44,
    captionFontName: options.captionFontName || "Arial",
    captionFontSize: Number.isFinite(options.captionFontSize) ? Math.max(18, Math.min(96, Number(options.captionFontSize))) : 48
  };

  let videoResult, usedEngine = "sora";
  try {
    videoResult = await generateVideoWithSora({ idea, editedScript: edited, plan, durationSec, images });
  } catch {
    usedEngine = "fallback";
    videoResult = await generateVideoFallback({
      idea, editedScript: edited, plan, durationSec, images,
      overlayCtaText: cta, ...sceneOpts
    });
  }

  const analysis = await analyzeVideo({ idea, plan, audienceLanguage: usedLanguage });
  const narration = await generateNarration({ editedScript: edited, plan, audienceLanguage: usedLanguage });

  const finalPath = await mergeVideoAndAudio({
    videoPath: videoResult.filePath,
    audioPath: narration.filePath,
    captionsText: narration.text,
    burnCaptions: options.burnCaptions !== false,
    addMusicIfAvailable: options.addMusic !== false,
    overlayCtaText: cta,
    overlayProgressBar: sceneOpts.progressBar,
    overlaySafeArea: sceneOpts.safeArea,
    progressThickness: sceneOpts.progressThickness,
    overlayFontName: sceneOpts.overlayFontName,
    overlayHookSize: sceneOpts.overlayHookSize,
    overlayCtaSize: sceneOpts.overlayCtaSize,
    captionFontName: sceneOpts.captionFontName,
    captionFontSize: sceneOpts.captionFontSize
  });

  const rel = path.relative(projectRoot, finalPath).replace(/\\/g, "/");
  const finalUrl = `/${rel}`;

  // Description + hashtags files
  const baseNoExt = finalPath.replace(/\.[^.]+$/, "");
  const metaPath = `${baseNoExt}.txt`;
  const descText = await generateDescription({ platform, language: usedLanguage, idea, editedScript: edited });
  const hashtagsLine = (hashtags||[]).join(" ");
  const meta = `Title: ${idea}

Description:
${descText}

CTA: ${cta}

Hashtags:
${hashtagsLine}
`;
  try { fs.writeFileSync(metaPath, meta, "utf-8"); } catch {}
  const metaUrl = finalUrl.replace(/\.[^.]+$/, ".txt");

  // JSON metadata
  const jsonPath = `${baseNoExt}.json`;
  const jsonMeta = {
    title: idea,
    description: descText,
    cta, hashtags,
    platform, language: usedLanguage, engine: usedEngine,
    safeArea: sceneOpts.safeArea,
    durations: { requested: durationSec || cfg.VIDEO_DEFAULT_SEC },
    files: { video: finalUrl, txt: metaUrl, json: finalUrl.replace(/\.[^.]+$/, ".json") },
    createdAt: new Date().toISOString()
  };
  try { fs.writeFileSync(jsonPath, JSON.stringify(jsonMeta, null, 2), "utf-8"); } catch {}
  const jsonUrl = finalUrl.replace(/\.[^.]+$/, ".json");

  return {
    usedLanguage,
    engine: usedEngine,
    trends: ideas,
    script: { draft: script, edited },
    plan,
    cta,
    hashtags,
    video: { ...videoResult, analysis },
    narration,
    output: { finalPath, finalUrl, metaPath, metaUrl, jsonPath, jsonUrl }
  };
}
