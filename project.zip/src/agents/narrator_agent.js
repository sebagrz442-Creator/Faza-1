import path from "path";
import { fileURLToPath } from "url";
import { ttsToFile, callChat } from "./openai_client.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");

export async function generateNarration({ editedScript, plan, audienceLanguage }) {
  const refined = await callChat(
    `Rewrite the narration for a ${plan.tone} tone, ${plan.pace} pace, in ${audienceLanguage}. Keep meaning. 80-120 words.`,
    editedScript
  );
  const ts = Date.now();
  const outPath = path.join(projectRoot, "videos", `narration_${ts}.mp3`);
  await ttsToFile({ text: refined, voice: plan.voice, format: "mp3", outPath });
  return { text: refined, voice: plan.voice, filePath: outPath };
}
