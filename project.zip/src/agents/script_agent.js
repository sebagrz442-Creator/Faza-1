import { callChat } from "./openai_client.js";
export async function generateScript({ idea, platform, audienceLanguage }) {
  const sys = `You are a senior short-form scriptwriter. Write a tight script for ${platform}. Language: ${audienceLanguage}. 3 acts max, punchy hooks.`;
  const user = `Idea: ${idea}\nWrite a voiceover script (80-120 words). Return only the script text.`;
  return callChat(sys, user);
}
