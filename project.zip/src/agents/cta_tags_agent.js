import { callChat } from "./openai_client.js";
export async function generateCtaAndTags({ platform, topic, language }) {
  const lang = String(platform || "").toLowerCase() === "tiktok" ? "English" : (language || "English");
  const sys = `You craft short CTAs and hashtags for short-form videos on ${platform}. Language: ${lang}.`;
  const user = `Topic: ${topic}
Return JSON:
{
  "cta": "short punchy CTA (<= 8 words)",
  "hashtags": ["#tag1", "#tag2", "... up to 8"]
}`;
  const txt = await callChat(sys, user);
  let cta = "Follow for more";
  let hashtags = ["#fyp", "#viral"];
  try {
    const j = JSON.parse(txt);
    if (j?.cta) cta = String(j.cta).trim();
    if (Array.isArray(j?.hashtags) && j.hashtags.length) {
      hashtags = j.hashtags.slice(0, 8).map(s => s.trim()).filter(Boolean);
    }
  } catch {}
  return { cta, hashtags };
}
