import OpenAI from "openai";
import fs from "fs";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL_GPT = process.env.OPENAI_MODEL_GPT || "gpt-4.1-mini";

export async function callChat(system, user, extra = {}) {
  const input = [
    { role: "system", content: system },
    { role: "user", content: user }
  ];
  const response = await client.responses.create({ model: MODEL_GPT, input, ...extra });
  const first = response?.output?.[0]?.content?.[0];
  return typeof first?.text === "string" ? first.text : "";
}

export async function ttsToFile({ text, voice = "alloy", format = "mp3", outPath }) {
  const resp = await client.audio.speech.create({
    model: "gpt-4o-mini-tts",
    voice,
    input: text,
    format
  });
  const arrayBuffer = await resp.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  fs.writeFileSync(outPath, buffer);
  return outPath;
}

export { client as openaiClient };
