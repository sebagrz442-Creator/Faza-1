import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../lib/utils.js";
import { runFullPipeline } from "../agents/orchestrator.js";

const router = Router();

const OptionsSchema = z.object({
  zoomMode: z.enum(["in","out","mix"]).optional(),
  transitionsMode: z.enum(["auto","soft","hard"]).optional(),
  progressBar: z.coerce.boolean().optional(),
  burnCaptions: z.coerce.boolean().optional(),
  addMusic: z.coerce.boolean().optional(),
  safeArea: z.enum(["none","tiktok","tiktok_strict"]).optional(),
  progressThickness: z.coerce.number().int().min(2).max(24).optional(),
  overlayFontName: z.string().optional(),
  overlayHookSize: z.coerce.number().int().min(18).max(96).optional(),
  overlayCtaSize: z.coerce.number().int().min(18).max(96).optional(),
  captionFontName: z.string().optional(),
  captionFontSize: z.coerce.number().int().min(18).max(96).optional()
}).optional();

const RunSchema = z.object({
  topic: z.string().min(3),
  platform: z.string().default("TikTok"),
  audienceLanguage: z.string().default("English"),
  durationSec: z.coerce.number().int().optional(),
  options: OptionsSchema
});

router.post("/run", asyncHandler(async (req, res) => {
  const parsed = RunSchema.safeParse(req.body || {});
  if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error.flatten() });

  const data = parsed.data;
  const result = await runFullPipeline({ ...data });
  res.json({ ok: true, data: result });
}));

export const pipelineRouter = router;
