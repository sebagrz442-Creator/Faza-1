import { Router } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { asyncHandler } from "../lib/utils.js";
import { fileURLToPath } from "url";

const router = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const slug = String(req.query.slug || "shared").toLowerCase().replace(/[^a-z0-9\-]/g,"-").slice(0,60) || "shared";
    const dir = path.join(projectRoot, "assets", "images", slug);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (_req, file, cb) => {
    const ts = Date.now();
    const ext = (file.originalname || "").toLowerCase().match(/\.(jpg|jpeg|png|webp)$/)?.[0] || ".jpg";
    cb(null, `up_${ts}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /\.(jpg|jpeg|png|webp)$/i.test(file.originalname || "");
    cb(ok ? null : new Error("Only jpg/jpeg/png/webp allowed"), ok);
  }
});

router.post("/images", upload.array("files", 10), asyncHandler(async (req, res) => {
  const slug = String(req.query.slug || "shared");
  const files = (req.files || []).map(f => ({ name: f.filename, path: f.path, url: `/assets/images/${slug}/${f.filename}` }));
  res.json({ ok: true, slug, uploaded: files.length, files });
}));

router.get("/images", asyncHandler(async (req, res) => {
  const slug = String(req.query.slug || "shared");
  const dir = path.join(projectRoot, "assets", "images", slug);
  if (!fs.existsSync(dir)) return res.json({ ok: true, slug, files: [] });
  const list = fs.readdirSync(dir).filter(f => /\.(jpg|jpeg|png|webp)$/i.test(f))
    .map(f => ({ name: f, url: `/assets/images/${slug}/${f}` }));
  res.json({ ok: true, slug, files: list });
}));

export const uploadRouter = router;
