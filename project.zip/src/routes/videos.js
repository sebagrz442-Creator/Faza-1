import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { asyncHandler } from "../lib/utils.js";

const router = Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..", "..");
const videosDir = path.join(projectRoot, "videos");

router.get("/", asyncHandler(async (_req, res) => {
  try {
    const files = fs.readdirSync(videosDir).filter(f => /\.(mp4|mov|m4v)$/i.test(f));
    const list = files.map(f => {
      const p = path.join(videosDir, f);
      const st = fs.statSync(p);
      const base = f.replace(/\.[^.]+$/, "");
      const txt = `${base}.txt`, jsonF = `${base}.json`;
      const meta = {};
      const txtPath = path.join(videosDir, txt); const jsonPath = path.join(videosDir, jsonF);
      let metaUrlTxt = null, metaUrlJson = null;
      if (fs.existsSync(txtPath)) metaUrlTxt = `/videos/${txt}`;
      if (fs.existsSync(jsonPath)) { metaUrlJson = `/videos/${jsonF}`; try { Object.assign(meta, JSON.parse(fs.readFileSync(jsonPath,'utf-8')));} catch {} }
      return { name: f, url: `/videos/${f}`, size: st.size, mtime: st.mtimeMs, metaTxt: metaUrlTxt, metaJson: metaUrlJson, meta };
    }).sort((a,b)=> b.mtime - a.mtime);
    res.json({ ok: true, videos: list });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
}));

export const videosRouter = router;
