#!/usr/bin/env node
import dotenv from "dotenv";
dotenv.config();
const PORT = Number(process.env.PORT || 3000);
const BASE = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
function arg(name, def) { const i = process.argv.indexOf(`--${name}`); return i!==-1 && process.argv[i+1] ? process.argv[i+1] : def; }
if (process.argv.includes("--help")||process.argv.includes("-h")) {
  console.log("Usage: node scripts/smoke.js --topic \"Your topic\" [--platform TikTok] [--lang English] [--duration 20]"); process.exit(0);
}
const topic = arg("topic", "Auto smoke test");
const platform = arg("platform", "TikTok");
const audienceLanguage = arg("lang", "English");
const durationSec = Number(arg("duration", process.env.VIDEO_DEFAULT_SEC || 20));
async function main(){
  console.log(`[SMOKE] BASE=${BASE}`);
  const h = await fetch(`${BASE}/healthz`); if (!h.ok) throw new Error(`/healthz failed: ${h.status}`);
  console.log("[SMOKE] /healthz ok");
  const body = { topic, platform, audienceLanguage, durationSec, options: { safeArea: "tiktok_strict", progressThickness: 10 } };
  console.log("[SMOKE] POST /api/pipeline/run", body);
  const r = await fetch(`${BASE}/api/pipeline/run`, { method:"POST", headers:{ "content-type":"application/json" }, body: JSON.stringify(body) });
  const j = await r.json().catch(()=>({}));
  if (!r.ok || !j?.ok) { console.error("[SMOKE] pipeline failed:", r.status, j); process.exit(2); }
  const finalUrl = j?.data?.output?.finalUrl || null;
  console.log("[SMOKE] pipeline ok"); if (finalUrl) console.log("[SMOKE] finalUrl:", `${BASE.replace(/\/$/, "")}${finalUrl}`);
}
main().catch(e=>{ console.error("[SMOKE] error:", e.message || e); process.exit(1); });
