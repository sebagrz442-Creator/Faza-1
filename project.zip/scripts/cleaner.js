#!/usr/bin/env node
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { loadConfig } from "../src/lib/config.js";
import { runCleanup } from "../src/lib/cleanup.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, "..");
const videosDir = path.join(projectRoot, "videos");

const cfg = (() => {
  try { return loadConfig(); } catch {
    return {
      CLEAN_KEEP_DAYS: Number(process.env.CLEAN_KEEP_DAYS || 7),
      CLEAN_MAX_FILES: Number(process.env.CLEAN_MAX_FILES || 500),
      CLEAN_MAX_SIZE_GB: Number(process.env.CLEAN_MAX_SIZE_GB || 5)
    };
  }
})();

const days = Number(process.env.DAYS || cfg.CLEAN_KEEP_DAYS);
const maxFiles = Number(process.env.MAX_FILES || cfg.CLEAN_MAX_FILES);
const maxSizeGB = Number(process.env.MAX_SIZE_GB || cfg.CLEAN_MAX_SIZE_GB);

const stats = await runCleanup({ dir: videosDir, maxAgeDays: days, maxFiles, maxSizeGB });
console.log(JSON.stringify({ ok: true, dir: videosDir, days, maxFiles, maxSizeGB, ...stats }, null, 2));
