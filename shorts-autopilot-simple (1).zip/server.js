const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = (process.env.ADMIN_TOKEN || "").trim();
const UI_DEFAULT_LANG = process.env.UI_DEFAULT_LANG || "pl";
const CONTENT_LANGUAGE = process.env.CONTENT_LANGUAGE || "en";

const ROOT = process.cwd();
const PUBLIC_DIR = path.join(ROOT, "public");
const VIDEOS_DIR = path.join(ROOT, "videos");
[PUBLIC_DIR, VIDEOS_DIR].forEach((d) => {
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
});

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(PUBLIC_DIR));

function adminGuard(req, res, next) {
  const incoming =
    (req.headers["x-admin-token"] ||
      req.query.token ||
      req.body?.adminToken ||
      "").toString().trim();
  if (!ADMIN_TOKEN) {
    return res.status(500).json({ ok: false, error: "ADMIN_TOKEN not configured" });
  }
  if (!incoming || incoming !== ADMIN_TOKEN) {
    return res.status(401).json({ ok: false, error: "unauthorized" });
  }
  next();
}

app.get("/healthz", (req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

const TOPIC_TYPES = [
  { id: "money_hacks", label: "Money hacks / side hustles" },
  { id: "self_improvement", label: "Self improvement" },
  { id: "fitness", label: "Fitness & health" },
  { id: "business_mindset", label: "Business & mindset" },
  { id: "short_story", label: "Short story / anecdote" }
];

app.get("/api/topics/types", (req, res) => {
  res.json({ ok: true, contentLanguage: CONTENT_LANGUAGE, types: TOPIC_TYPES });
});

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

app.post("/api/topics/generate", adminGuard, (req, res) => {
  const { typeId, lengthSec, energy, style } = req.body || {};
  const type = TOPIC_TYPES.find((t) => t.id === typeId) || TOPIC_TYPES[0];
  const total = clamp(Number(lengthSec) || 25, 15, 40);
  const energyNorm = (energy || "medium").toLowerCase();
  const styleNorm = (style || "educational").toLowerCase();

  const ideaMap = {
    money_hacks: "3 habits that fix your money in 6 months",
    self_improvement: "Simple way to beat procrastination every morning",
    fitness: "Tiny daily habit that burns calories on autopilot",
    business_mindset: "One mindset shift separating amateurs from pros",
    short_story: "A tiny decision that changed everything"
  };
  const idea = ideaMap[type.id] || ideaMap.self_improvement;

  const prefix = energyNorm === "high"
    ? "STOP SCROLLING! "
    : energyNorm === "low"
    ? "Soft truth: "
    : "Real talk: ";
  const suffix = styleNorm === "story"
    ? " Let me tell you a short story."
    : styleNorm === "hard-sell"
    ? " If this hits you, follow right now."
    : " Nobody told you this at school.";

  const hook = `${prefix}${idea}.${suffix}`;

  const beats = [];
  const count = 4;
  const seg = Math.floor(total / count);
  const roles = ["HOOK", "POINT_1", "POINT_2", "CTA"];

  for (let i = 0; i < count; i++) {
    const t = i * seg;
    let text;
    if (i === 0) text = hook;
    else if (i === count - 1) {
      text = "If this helped you, follow for more daily insights.";
    } else {
      text = `Key point #${i} about ${type.label.toLowerCase()}.`;
    }
    beats.push({ t, role: roles[i] || "POINT", text });
  }

  const captions = [
    "Small daily habits ➜ massive change.",
    "Save this and watch it again tomorrow."
  ];
  const hashtags = ["#tiktok", "#fyp", "#viral", "#shorts", "#motivation"];

  res.json({
    ok: true,
    contentLanguage: CONTENT_LANGUAGE,
    type,
    config: { lengthSec: total, energy: energyNorm, style: styleNorm },
    idea,
    hook,
    beats,
    captions,
    hashtags
  });
});

app.post("/api/pipeline/run", adminGuard, async (req, res) => {
  try {
    const payload = req.body || {};
    const id = Date.now().toString();
    const meta = {
      id,
      ok: true,
      createdAt: new Date().toISOString(),
      contentLanguage: CONTENT_LANGUAGE,
      note: "Stub pipeline – JSON only, no real video.",
      payload
    };
    const outPath = path.join(VIDEOS_DIR, `final_${id}.json`);
    await fsp.writeFile(outPath, JSON.stringify(meta, null, 2), "utf-8");
    res.json({ ok: true, id, artifact: `/videos/final_${id}.json` });
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err) });
  }
});

async function collectSnapshot() {
  const snapshot = {};
  const files = ["package.json", "server.js", path.join("public", "app.js")];
  for (const rel of files) {
    const p = path.join(ROOT, rel);
    try {
      const stat = await fsp.stat(p);
      if (stat.isFile() && stat.size < 40 * 1024) {
        snapshot[rel] = await fsp.readFile(p, "utf-8");
      } else {
        snapshot[rel] = "Too big or not a file.";
      }
    } catch {
      snapshot[rel] = "Missing.";
    }
  }
  return snapshot;
}

function localAnalysis() {
  const problems = [];
  const infos = [];

  if (!ADMIN_TOKEN) {
    problems.push("ADMIN_TOKEN is not set. Protect this before production.");
  }
  if (!fs.existsSync(PUBLIC_DIR)) {
    problems.push("public/ missing. Frontend UI will not load.");
  }
  if (!fs.existsSync(path.join(ROOT, ".env"))) {
    infos.push("No .env file. Copy .env.example and configure it.");
  }
  infos.push("Content language is forced to English for scripts and captions.");
  return { problems, infos };
}

app.post("/api/dev-bot/analyse", adminGuard, async (req, res) => {
  try {
    const { question } = req.body || {};
    const snapshot = await collectSnapshot();
    const staticResult = localAnalysis();
    res.json({
      ok: true,
      static: staticResult,
      hint: "Integrate with real video renderer or TikTok API later.",
      question: question || null,
      snapshotSummary: Object.keys(snapshot)
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: String(err) });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.listen(PORT, () => {
  console.log(`[shorts-autopilot-simple] listening on :${PORT}`);
});
