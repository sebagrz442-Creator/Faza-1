(function () {
  const adminTokenInput = document.getElementById("adminToken");
  const statusOutput = document.getElementById("statusOutput");
  const topicTypeSelect = document.getElementById("topicType");
  const lengthInput = document.getElementById("lengthSec");
  const energySelect = document.getElementById("energy");
  const styleSelect = document.getElementById("style");
  const generatorOutput = document.getElementById("generatorOutput");
  const pipelineOutput = document.getElementById("pipelineOutput");
  const devBotOutput = document.getElementById("devBotOutput");

  function getAdminToken() {
    return (localStorage.getItem("adminToken") || "").trim();
  }
  function setAdminToken(val) {
    localStorage.setItem("adminToken", val || "");
  }

  function applyToken() {
    const t = getAdminToken();
    if (t) adminTokenInput.value = t;
  }

  async function callApi(path, options) {
    const token = getAdminToken();
    const headers = Object.assign(
      { "Content-Type": "application/json" },
      (options && options.headers) || {}
    );
    if (token) headers["x-admin-token"] = token;

    const resp = await fetch(path, {
      method: (options && options.method) || "GET",
      headers,
      body: options && options.body ? JSON.stringify(options.body) : undefined
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || data.ok === false) {
      throw new Error(data.error || "HTTP " + resp.status);
    }
    return data;
  }

  async function loadTopicTypes() {
    try {
      const resp = await fetch("/api/topics/types");
      const data = await resp.json();
      topicTypeSelect.innerHTML = "";
      (data.types || []).forEach((t) => {
        const opt = document.createElement("option");
        opt.value = t.id;
        opt.textContent = t.label;
        topicTypeSelect.appendChild(opt);
      });
    } catch (e) {
      console.error("Failed to load topic types", e);
    }
  }

  async function onCheckStatus() {
    statusOutput.textContent = "Working...";
    try {
      const data = await callApi("/api/admin/status", { method: "GET" });
      statusOutput.textContent = JSON.stringify(data, null, 2);
    } catch (e) {
      statusOutput.textContent = "Error: " + e.message;
    }
  }

  async function onGenerate() {
    generatorOutput.textContent = "Working...";
    try {
      const body = {
        typeId: topicTypeSelect.value,
        lengthSec: Number(lengthInput.value || 25),
        energy: energySelect.value,
        style: styleSelect.value
      };
      const data = await callApi("/api/topics/generate", {
        method: "POST",
        body
      });
      generatorOutput.textContent = JSON.stringify(data, null, 2);
      window.__lastGenerated = data;
    } catch (e) {
      generatorOutput.textContent = "Error: " + e.message;
    }
  }

  async function onPipeline() {
    pipelineOutput.textContent = "Working...";
    try {
      const payload = window.__lastGenerated || { info: "No generated script yet." };
      const data = await callApi("/api/pipeline/run", {
        method: "POST",
        body: payload
      });
      pipelineOutput.textContent = JSON.stringify(data, null, 2);
    } catch (e) {
      pipelineOutput.textContent = "Error: " + e.message;
    }
  }

  async function onDevAnalyse() {
    devBotOutput.textContent = "Working...";
    try {
      const q = document.getElementById("devQuestion").value || "";
      const data = await callApi("/api/dev-bot/analyse", {
        method: "POST",
        body: { question: q }
      });
      devBotOutput.textContent = JSON.stringify(data, null, 2);
    } catch (e) {
      devBotOutput.textContent = "Error: " + e.message;
    }
  }

  function onSaveToken() {
    const val = adminTokenInput.value.trim();
    setAdminToken(val);
    statusOutput.textContent = "Token saved locally.";
  }

  function init() {
    applyToken();
    loadTopicTypes();

    document.getElementById("saveTokenBtn").addEventListener("click", onSaveToken);
    document.getElementById("checkStatusBtn").addEventListener("click", onCheckStatus);
    document.getElementById("generateBtn").addEventListener("click", onGenerate);
    document.getElementById("runPipelineBtn").addEventListener("click", onPipeline);
    document.getElementById("devAnalyseBtn").addEventListener("click", onDevAnalyse);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
