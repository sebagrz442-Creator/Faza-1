# Shorts Autopilot – simple

## Instalacja

```bash
npm install
cp .env.example .env
# edytuj .env i ustaw ADMIN_TOKEN
```

## Start

```bash
node server.js
# panel: http://localhost:3000
```

## Funkcje

- Generator scenariusza (EN) dla różnych tematów.
- Pipeline stub zapisujący JSON w `videos/`.
- Bot-developer (`/api/dev-bot/analyse`) – lokalna analiza projektu.
